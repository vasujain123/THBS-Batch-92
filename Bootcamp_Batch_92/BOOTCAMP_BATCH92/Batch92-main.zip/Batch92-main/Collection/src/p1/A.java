package p1;

public class A {

	Parent foo() {

		return null;
	}

}

class B extends A {

	@Override
	Child3 foo() {

		return null;
	}
}
