package p5;
class Dog {
		@Override
		public String toString() {

			return "Dog";
		}
	}