package p5;

class Cat {
	@Override
	public String toString() {
		return "Cat";
	}
}