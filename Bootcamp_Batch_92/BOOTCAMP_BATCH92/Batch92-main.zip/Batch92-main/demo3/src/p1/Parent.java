package p1;

public class Parent {
	
	public Parent() {
		System.out.println("Parent");
	}
	
	int i=10;

}
