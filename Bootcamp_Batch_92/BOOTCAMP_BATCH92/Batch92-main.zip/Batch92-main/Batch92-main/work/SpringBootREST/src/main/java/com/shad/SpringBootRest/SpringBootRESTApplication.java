package com.shad.SpringBootRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRESTApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRESTApplication.class, args);
	}

}
