package p3;

public class MyException extends RuntimeException {
	
	public MyException(String reason) {
		super(reason);
	}
}
