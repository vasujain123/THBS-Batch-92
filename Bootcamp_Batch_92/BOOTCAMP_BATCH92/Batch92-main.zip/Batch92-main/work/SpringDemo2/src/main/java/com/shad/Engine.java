package com.shad;


public class Engine {

	void startEngine() {
		System.out.println("Engine is starting...");

	}

}
