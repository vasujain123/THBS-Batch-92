package p2;

public class Car {

	int h;
	int w;

	static float wc;

	void move() {
	}

	static void avg() {
	}

	public static void main(String[] args) {
		Car c = new Car(); //c is a reference variable
		
		
		int i =10;
	}
}
