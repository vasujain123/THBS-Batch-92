package p4;

public class Child extends Parent {

	@Override
	void m1() {
		System.out.println("I am SON");
	}

	@Override
	void m2() {
		System.out.println("I am DAUGHTER");
	}
}
