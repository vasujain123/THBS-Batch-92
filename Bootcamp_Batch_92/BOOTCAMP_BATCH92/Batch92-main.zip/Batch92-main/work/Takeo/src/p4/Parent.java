package p4;

final public class Parent {

	 	void m1() {
		System.out.println("I am PAPA");
	}
	 
	 	void m2() {
		System.out.println("I am MUMMY");
	}

}
