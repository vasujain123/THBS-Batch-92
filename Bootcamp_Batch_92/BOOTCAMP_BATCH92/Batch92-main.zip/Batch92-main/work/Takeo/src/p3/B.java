package p3;


public abstract class B {

	void f1() {
	}

	abstract void f2();
	
	public static void main(String[] args) {
		B obj = new B();
	}

}
