package p3;


abstract public class A {

	void m1() {
	}

	void m2() {
	}

	public static void main(String[] args) {
		A obj = new A();
	}

}
